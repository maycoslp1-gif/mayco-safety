"use server";

import { db } from "@/db";
import { courses, modules, questions, options, enrollments, users } from "@/db/schema";
import { auth } from "@/lib/auth";
import { eq, sql } from "drizzle-orm";
import { revalidatePath } from "next/cache";

async function requireAdmin() {
  const session = await auth();
  if (!session || session.user.role !== "admin") {
    throw new Error("No autorizado");
  }
  return session;
}

export async function crearCurso(data: {
  title: string;
  description: string;
  category: string;
  coverColor: string;
  passingScore: number;
}) {
  const session = await requireAdmin();
  const [curso] = await db
    .insert(courses)
    .values({
      ...data,
      createdById: session.user.id,
    })
    .returning();
  revalidatePath("/admin/cursos");
  return curso;
}

export async function actualizarCurso(
  id: string,
  data: Partial<{
    title: string;
    description: string;
    category: string;
    coverColor: string;
    passingScore: number;
    published: boolean;
  }>
) {
  await requireAdmin();
  await db
    .update(courses)
    .set({ ...data, updatedAt: sql`(current_timestamp)` })
    .where(eq(courses.id, id));
  revalidatePath("/admin/cursos");
  revalidatePath(`/admin/cursos/${id}`);
}

export async function eliminarCurso(id: string) {
  await requireAdmin();
  await db.delete(courses).where(eq(courses.id, id));
  revalidatePath("/admin/cursos");
}

export async function agregarModulo(data: {
  courseId: string;
  title: string;
  type: "texto" | "video" | "pdf" | "imagen";
  content: string;
}) {
  await requireAdmin();
  const existentes = await db
    .select({ id: modules.id })
    .from(modules)
    .where(eq(modules.courseId, data.courseId));
  const [mod] = await db
    .insert(modules)
    .values({ ...data, order: existentes.length + 1 })
    .returning();
  revalidatePath(`/admin/cursos/${data.courseId}`);
  return mod;
}

export async function eliminarModulo(id: string, courseId: string) {
  await requireAdmin();
  await db.delete(modules).where(eq(modules.id, id));
  revalidatePath(`/admin/cursos/${courseId}`);
}

export async function agregarPregunta(data: {
  courseId: string;
  prompt: string;
  type: "opcion_unica" | "verdadero_falso";
  opciones: { text: string; isCorrect: boolean }[];
}) {
  await requireAdmin();
  const existentes = await db
    .select({ id: questions.id })
    .from(questions)
    .where(eq(questions.courseId, data.courseId));

  const [pregunta] = await db
    .insert(questions)
    .values({
      courseId: data.courseId,
      prompt: data.prompt,
      type: data.type,
      order: existentes.length + 1,
    })
    .returning();

  await db.insert(options).values(
    data.opciones.map((op, i) => ({
      questionId: pregunta.id,
      text: op.text,
      isCorrect: op.isCorrect,
      order: i + 1,
    }))
  );

  revalidatePath(`/admin/cursos/${data.courseId}/examen`);
  return pregunta;
}

export async function eliminarPregunta(id: string, courseId: string) {
  await requireAdmin();
  await db.delete(questions).where(eq(questions.id, id));
  revalidatePath(`/admin/cursos/${courseId}/examen`);
}

export async function asignarCursoAEmpleados(courseId: string, userIds: string[]) {
  await requireAdmin();
  for (const userId of userIds) {
    const ya = await db
      .select({ id: enrollments.id })
      .from(enrollments)
      .where(sql`${enrollments.courseId} = ${courseId} AND ${enrollments.userId} = ${userId}`)
      .limit(1);
    if (ya.length === 0) {
      await db.insert(enrollments).values({ courseId, userId });
    }
  }
  revalidatePath(`/admin/cursos/${courseId}`);
}

export async function crearEmpleado(data: {
  name: string;
  email: string;
  password: string;
  area?: string;
  puesto?: string;
}) {
  await requireAdmin();
  const bcrypt = await import("bcryptjs");
  const passwordHash = await bcrypt.hash(data.password, 10);
  const [empleado] = await db
    .insert(users)
    .values({
      name: data.name,
      email: data.email.toLowerCase().trim(),
      passwordHash,
      role: "empleado",
      area: data.area,
      puesto: data.puesto,
    })
    .returning();
  revalidatePath("/admin/empleados");
  return empleado;
}

export async function desactivarEmpleado(id: string, activo: boolean) {
  await requireAdmin();
  await db.update(users).set({ activo }).where(eq(users.id, id));
  revalidatePath("/admin/empleados");
}
