"use server";

import { db } from "@/db";
import { enrollments, questions, options, examAttempts, courses } from "@/db/schema";
import { auth } from "@/lib/auth";
import { eq, and, sql } from "drizzle-orm";
import { revalidatePath } from "next/cache";

async function requireUser() {
  const session = await auth();
  if (!session) throw new Error("No autorizado");
  return session;
}

export async function marcarProgreso(courseId: string, progressPct: number) {
  const session = await requireUser();
  const status = progressPct >= 100 ? "completado" : progressPct > 0 ? "en_progreso" : "pendiente";

  await db
    .update(enrollments)
    .set({
      progressPct,
      status,
      completedAt: progressPct >= 100 ? sql`(current_timestamp)` : null,
    })
    .where(and(eq(enrollments.courseId, courseId), eq(enrollments.userId, session.user.id)));

  revalidatePath(`/app/cursos/${courseId}`);
  revalidatePath("/app/cursos");
}

export async function enviarExamen(
  courseId: string,
  respuestas: Record<string, string> // questionId -> optionId elegido
) {
  const session = await requireUser();

  const preguntas = await db
    .select()
    .from(questions)
    .where(eq(questions.courseId, courseId));

  let correctas = 0;

  for (const pregunta of preguntas) {
    const opcionesPregunta = await db
      .select()
      .from(options)
      .where(eq(options.questionId, pregunta.id));

    const correcta = opcionesPregunta.find((o) => o.isCorrect);
    const elegidaId = respuestas[pregunta.id];

    if (correcta && elegidaId === correcta.id) {
      correctas++;
    }
  }

  const total = preguntas.length || 1;
  const score = Math.round((correctas / total) * 100);

  const [curso] = await db.select().from(courses).where(eq(courses.id, courseId)).limit(1);
  const passed = score >= (curso?.passingScore ?? 80);

  const [intento] = await db
    .insert(examAttempts)
    .values({
      courseId,
      userId: session.user.id,
      score,
      passed,
      answersJson: JSON.stringify(respuestas),
    })
    .returning();

  if (passed) {
    await db
      .update(enrollments)
      .set({ status: "completado", progressPct: 100, completedAt: sql`(current_timestamp)` })
      .where(and(eq(enrollments.courseId, courseId), eq(enrollments.userId, session.user.id)));
  }

  revalidatePath(`/app/cursos/${courseId}`);
  revalidatePath("/app/cursos");
  revalidatePath("/app/historial");

  return { score, passed, total, correctas, attemptId: intento.id };
}
