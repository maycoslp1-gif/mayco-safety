"use client";

import { useState, useTransition } from "react";
import { agregarPregunta, eliminarPregunta } from "@/lib/actions/admin";

type Opcion = { id: string; text: string; isCorrect: boolean };
type Pregunta = {
  id: string;
  prompt: string;
  type: "opcion_unica" | "verdadero_falso";
  options: Opcion[];
};

export default function ExamenEditor({
  courseId,
  preguntasIniciales,
}: {
  courseId: string;
  preguntasIniciales: Pregunta[];
}) {
  const [isPending, startTransition] = useTransition();
  const [showForm, setShowForm] = useState(false);
  const [tipo, setTipo] = useState<"opcion_unica" | "verdadero_falso">("opcion_unica");
  const [prompt, setPrompt] = useState("");
  const [opciones, setOpciones] = useState(["", "", "", ""]);
  const [correctaIdx, setCorrectaIdx] = useState(0);
  const [vfCorrecta, setVfCorrecta] = useState<"Verdadero" | "Falso">("Verdadero");

  const resetForm = () => {
    setPrompt("");
    setOpciones(["", "", "", ""]);
    setCorrectaIdx(0);
    setTipo("opcion_unica");
    setShowForm(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    startTransition(async () => {
      if (tipo === "verdadero_falso") {
        await agregarPregunta({
          courseId,
          prompt,
          type: "verdadero_falso",
          opciones: [
            { text: "Verdadero", isCorrect: vfCorrecta === "Verdadero" },
            { text: "Falso", isCorrect: vfCorrecta === "Falso" },
          ],
        });
      } else {
        const opcionesValidas = opciones.filter((o) => o.trim() !== "");
        await agregarPregunta({
          courseId,
          prompt,
          type: "opcion_unica",
          opciones: opcionesValidas.map((text, i) => ({
            text,
            isCorrect: i === correctaIdx,
          })),
        });
      }
      resetForm();
    });
  };

  const handleDelete = (id: string) => {
    startTransition(async () => {
      await eliminarPregunta(id, courseId);
    });
  };

  return (
    <div className="space-y-3">
      {preguntasIniciales.map((p, i) => (
        <div key={p.id} className="bg-white border border-[var(--line)] rounded-lg p-4">
          <div className="flex items-start justify-between gap-3">
            <p className="text-sm font-medium">
              <span className="font-mono text-xs text-[var(--muted)] mr-2">{i + 1}.</span>
              {p.prompt}
            </p>
            <button
              onClick={() => handleDelete(p.id)}
              disabled={isPending}
              className="text-xs text-[var(--danger)] shrink-0 hover:underline"
            >
              Eliminar
            </button>
          </div>
          <div className="mt-2 flex flex-wrap gap-2">
            {p.options.map((o) => (
              <span
                key={o.id}
                className={`text-xs rounded-full px-2.5 py-1 ${
                  o.isCorrect
                    ? "bg-[var(--success-bg)] text-[var(--success)] font-medium"
                    : "bg-[var(--bg)] text-[var(--muted)]"
                }`}
              >
                {o.isCorrect ? "✓ " : ""}
                {o.text}
              </span>
            ))}
          </div>
        </div>
      ))}

      {!showForm && (
        <button
          onClick={() => setShowForm(true)}
          className="w-full rounded-lg border border-dashed border-[var(--line)] py-3 text-sm text-[var(--muted)] hover:border-[var(--orange)] hover:text-[var(--orange)] transition-colors"
        >
          + Agregar pregunta
        </button>
      )}

      {showForm && (
        <form onSubmit={handleSubmit} className="bg-white border border-[var(--line)] rounded-lg p-4 space-y-3">
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => setTipo("opcion_unica")}
              className={`text-xs rounded-full px-3 py-1.5 border ${
                tipo === "opcion_unica"
                  ? "bg-[var(--navy)] text-white border-[var(--navy)]"
                  : "border-[var(--line)] text-[var(--muted)]"
              }`}
            >
              Opción múltiple
            </button>
            <button
              type="button"
              onClick={() => setTipo("verdadero_falso")}
              className={`text-xs rounded-full px-3 py-1.5 border ${
                tipo === "verdadero_falso"
                  ? "bg-[var(--navy)] text-white border-[var(--navy)]"
                  : "border-[var(--line)] text-[var(--muted)]"
              }`}
            >
              Verdadero / Falso
            </button>
          </div>

          <textarea
            required
            rows={2}
            placeholder="Escribe la pregunta..."
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            className="w-full rounded-md border border-[var(--line)] px-3 py-2 text-sm"
          />

          {tipo === "opcion_unica" ? (
            <div className="space-y-2">
              {opciones.map((op, i) => (
                <div key={i} className="flex items-center gap-2">
                  <input
                    type="radio"
                    name="correcta"
                    checked={correctaIdx === i}
                    onChange={() => setCorrectaIdx(i)}
                    className="accent-[var(--orange)]"
                  />
                  <input
                    required={i < 2}
                    placeholder={`Opción ${i + 1}${i < 2 ? "" : " (opcional)"}`}
                    value={op}
                    onChange={(e) => {
                      const next = [...opciones];
                      next[i] = e.target.value;
                      setOpciones(next);
                    }}
                    className="flex-1 rounded-md border border-[var(--line)] px-3 py-1.5 text-sm"
                  />
                </div>
              ))}
              <p className="text-[11px] text-[var(--muted)]">
                Selecciona el radio button de la respuesta correcta.
              </p>
            </div>
          ) : (
            <div className="flex gap-3">
              {(["Verdadero", "Falso"] as const).map((v) => (
                <label key={v} className="flex items-center gap-1.5 text-sm">
                  <input
                    type="radio"
                    name="vf"
                    checked={vfCorrecta === v}
                    onChange={() => setVfCorrecta(v)}
                    className="accent-[var(--orange)]"
                  />
                  {v}
                </label>
              ))}
            </div>
          )}

          <div className="flex gap-2 pt-1">
            <button
              type="button"
              onClick={resetForm}
              className="flex-1 rounded-md border border-[var(--line)] py-2 text-sm"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={isPending}
              className="flex-1 rounded-md bg-[var(--navy)] text-white py-2 text-sm disabled:opacity-60"
            >
              {isPending ? "Guardando..." : "Guardar pregunta"}
            </button>
          </div>
        </form>
      )}
    </div>
  );
}
