"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { signOut } from "next-auth/react";

const items = [
  { href: "/admin", label: "Resumen" },
  { href: "/admin/cursos", label: "Cursos" },
  { href: "/admin/empleados", label: "Empleados" },
  { href: "/admin/calificaciones", label: "Calif." },
];

export default function AdminMobileNav() {
  const pathname = usePathname();
  return (
    <div className="md:hidden sticky top-0 z-20 bg-[var(--navy)] text-white">
      <div className="flex items-center justify-between px-4 py-3">
        <span className="font-display uppercase tracking-wide text-base">
          Mayco · Admin
        </span>
        <button
          onClick={() => signOut({ callbackUrl: "/login" })}
          className="text-xs text-white/70 underline underline-offset-2"
        >
          Salir
        </button>
      </div>
      <div className="hazard-stripe-thin" />
      <div className="flex overflow-x-auto px-2 py-2 gap-1">
        {items.map((item) => {
          const active =
            item.href === "/admin"
              ? pathname === "/admin"
              : pathname.startsWith(item.href);
          return (
            <Link
              key={item.href}
              href={item.href}
              className={`shrink-0 rounded-full px-3.5 py-1.5 text-xs font-medium ${
                active ? "bg-[var(--orange)] text-white" : "bg-white/10 text-white/80"
              }`}
            >
              {item.label}
            </Link>
          );
        })}
      </div>
    </div>
  );
}
