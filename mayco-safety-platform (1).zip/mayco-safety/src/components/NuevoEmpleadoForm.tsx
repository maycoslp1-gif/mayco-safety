"use client";

import { useState, useTransition } from "react";
import { crearEmpleado } from "@/lib/actions/admin";

export default function NuevoEmpleadoForm() {
  const [open, setOpen] = useState(false);
  const [isPending, startTransition] = useTransition();
  const [error, setError] = useState("");
  const [form, setForm] = useState({ name: "", email: "", password: "", area: "", puesto: "" });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    startTransition(async () => {
      try {
        await crearEmpleado(form);
        setForm({ name: "", email: "", password: "", area: "", puesto: "" });
        setOpen(false);
      } catch {
        setError("No se pudo crear el empleado. Verifica que el correo no esté repetido.");
      }
    });
  };

  if (!open) {
    return (
      <button
        onClick={() => setOpen(true)}
        className="rounded-md bg-[var(--orange)] hover:bg-[var(--orange-dark)] text-white text-sm font-medium px-4 py-2.5"
      >
        + Nuevo empleado
      </button>
    );
  }

  return (
    <div className="fixed inset-0 bg-black/40 flex items-end md:items-center justify-center z-50">
      <form
        onSubmit={handleSubmit}
        className="bg-white w-full md:max-w-md rounded-t-2xl md:rounded-xl p-5 space-y-3 max-h-[90vh] overflow-y-auto"
      >
        <h2 className="font-display text-lg uppercase tracking-wide">Nuevo empleado</h2>
        <input
          required
          placeholder="Nombre completo"
          value={form.name}
          onChange={(e) => setForm({ ...form, name: e.target.value })}
          className="w-full rounded-md border border-[var(--line)] px-3 py-2 text-sm"
        />
        <input
          required
          type="email"
          placeholder="Correo electrónico"
          value={form.email}
          onChange={(e) => setForm({ ...form, email: e.target.value })}
          className="w-full rounded-md border border-[var(--line)] px-3 py-2 text-sm"
        />
        <input
          required
          type="text"
          placeholder="Contraseña temporal"
          value={form.password}
          onChange={(e) => setForm({ ...form, password: e.target.value })}
          className="w-full rounded-md border border-[var(--line)] px-3 py-2 text-sm"
        />
        <div className="grid grid-cols-2 gap-2">
          <input
            placeholder="Área (opcional)"
            value={form.area}
            onChange={(e) => setForm({ ...form, area: e.target.value })}
            className="w-full rounded-md border border-[var(--line)] px-3 py-2 text-sm"
          />
          <input
            placeholder="Puesto (opcional)"
            value={form.puesto}
            onChange={(e) => setForm({ ...form, puesto: e.target.value })}
            className="w-full rounded-md border border-[var(--line)] px-3 py-2 text-sm"
          />
        </div>

        {error && <p className="text-xs text-[var(--danger)]">{error}</p>}

        <div className="flex gap-2 pt-1">
          <button
            type="button"
            onClick={() => setOpen(false)}
            className="flex-1 rounded-md border border-[var(--line)] py-2 text-sm"
          >
            Cancelar
          </button>
          <button
            type="submit"
            disabled={isPending}
            className="flex-1 rounded-md bg-[var(--orange)] text-white py-2 text-sm disabled:opacity-60"
          >
            {isPending ? "Creando..." : "Crear empleado"}
          </button>
        </div>
      </form>
    </div>
  );
}
