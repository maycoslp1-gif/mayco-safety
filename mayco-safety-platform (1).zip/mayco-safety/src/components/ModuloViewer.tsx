"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { marcarProgreso } from "@/lib/actions/empleado";

type Modulo = {
  id: string;
  title: string;
  type: "texto" | "video" | "pdf" | "imagen";
  content: string;
  order: number;
};

function renderEmbed(m: Modulo) {
  if (m.type === "video") {
    return (
      <div className="aspect-video rounded-lg overflow-hidden bg-black">
        <iframe
          src={m.content}
          className="w-full h-full"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
        />
      </div>
    );
  }
  if (m.type === "imagen") {
    // eslint-disable-next-line @next/next/no-img-element
    return <img src={m.content} alt={m.title} className="w-full rounded-lg" />;
  }
  if (m.type === "pdf") {
    return (
      <a
        href={m.content}
        target="_blank"
        rel="noreferrer"
        className="block text-center rounded-lg border border-[var(--line)] bg-[var(--bg)] py-8 text-sm font-medium text-[var(--navy)]"
      >
        📄 Abrir documento PDF
      </a>
    );
  }
  return <p className="text-[15px] leading-relaxed whitespace-pre-wrap">{m.content}</p>;
}

export default function ModuloViewer({
  courseId,
  modulos,
  hasExam,
  yaCompletado,
}: {
  courseId: string;
  modulos: Modulo[];
  hasExam: boolean;
  yaCompletado: boolean;
}) {
  const router = useRouter();
  const [index, setIndex] = useState(0);
  const [isPending, startTransition] = useTransition();
  const ordenados = [...modulos].sort((a, b) => a.order - b.order);
  const total = ordenados.length;
  const actual = ordenados[index];
  const esUltimo = index === total - 1;

  if (total === 0) {
    return (
      <div className="bg-white border border-dashed border-[var(--line)] rounded-xl p-8 text-center text-sm text-[var(--muted)]">
        Este curso todavía no tiene contenido cargado.
      </div>
    );
  }

  const irSiguiente = () => {
    const progreso = Math.round(((index + 1) / total) * (hasExam ? 90 : 100));
    startTransition(async () => {
      await marcarProgreso(courseId, progreso);
      if (esUltimo) {
        if (hasExam) {
          router.push(`/app/cursos/${courseId}/examen`);
        } else {
          router.push("/app/cursos");
        }
      } else {
        setIndex(index + 1);
      }
    });
  };

  return (
    <div>
      <div className="flex items-center gap-1.5 mb-4">
        {ordenados.map((_, i) => (
          <div
            key={i}
            className={`h-1.5 flex-1 rounded-full ${
              i <= index ? "bg-[var(--orange)]" : "bg-[var(--bg)]"
            }`}
          />
        ))}
      </div>

      <div className="bg-white border border-[var(--line)] rounded-xl p-5">
        <span className="text-[11px] font-mono text-[var(--muted)]">
          Módulo {index + 1} de {total}
        </span>
        <h2 className="font-display text-xl mb-3 mt-0.5">{actual.title}</h2>
        {renderEmbed(actual)}
      </div>

      <div className="flex gap-2 mt-4">
        {index > 0 && (
          <button
            onClick={() => setIndex(index - 1)}
            className="rounded-md border border-[var(--line)] px-4 py-2.5 text-sm font-medium"
          >
            ← Atrás
          </button>
        )}
        <button
          onClick={irSiguiente}
          disabled={isPending}
          className="flex-1 rounded-md bg-[var(--orange)] hover:bg-[var(--orange-dark)] text-white font-semibold py-2.5 text-sm disabled:opacity-60"
        >
          {isPending
            ? "Guardando..."
            : esUltimo
            ? hasExam
              ? "Terminar y presentar examen →"
              : "Marcar como completado"
            : "Siguiente →"}
        </button>
      </div>

      {yaCompletado && (
        <p className="text-xs text-[var(--success)] text-center mt-3">
          Ya completaste este curso anteriormente. Puedes repasarlo cuando quieras.
        </p>
      )}
    </div>
  );
}
