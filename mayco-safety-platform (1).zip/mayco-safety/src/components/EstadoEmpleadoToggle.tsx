"use client";

import { useTransition } from "react";
import { desactivarEmpleado } from "@/lib/actions/admin";

export default function EstadoEmpleadoToggle({ id, activo }: { id: string; activo: boolean }) {
  const [isPending, startTransition] = useTransition();
  return (
    <button
      onClick={() => startTransition(() => desactivarEmpleado(id, !activo))}
      disabled={isPending}
      className={`text-[10px] font-mono uppercase rounded-full px-2.5 py-1 ${
        activo ? "bg-[var(--success-bg)] text-[var(--success)]" : "bg-[var(--danger-bg)] text-[var(--danger)]"
      }`}
    >
      {activo ? "Activo" : "Inactivo"}
    </button>
  );
}
