"use client";

import { useTransition } from "react";
import { actualizarCurso, eliminarCurso } from "@/lib/actions/admin";
import { useRouter } from "next/navigation";

export default function CursoAcciones({
  courseId,
  published,
}: {
  courseId: string;
  published: boolean;
}) {
  const [isPending, startTransition] = useTransition();
  const router = useRouter();

  const togglePublish = () => {
    startTransition(async () => {
      await actualizarCurso(courseId, { published: !published });
    });
  };

  const handleDelete = () => {
    if (!confirm("¿Eliminar este curso de forma permanente? Esta acción no se puede deshacer.")) {
      return;
    }
    startTransition(async () => {
      await eliminarCurso(courseId);
      router.push("/admin/cursos");
    });
  };

  return (
    <div className="flex items-center gap-2">
      <button
        onClick={togglePublish}
        disabled={isPending}
        className={`text-xs font-medium rounded-full px-3.5 py-1.5 ${
          published
            ? "bg-[var(--success-bg)] text-[var(--success)]"
            : "bg-amber-100 text-amber-700"
        }`}
      >
        {published ? "Publicado" : "Borrador · Publicar"}
      </button>
      <button
        onClick={handleDelete}
        disabled={isPending}
        className="text-xs text-[var(--danger)] hover:underline"
      >
        Eliminar curso
      </button>
    </div>
  );
}
