"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { signOut } from "next-auth/react";

export default function AppNav({ name }: { name: string }) {
  const pathname = usePathname();

  const items = [
    { href: "/app/cursos", label: "Mis cursos", icon: "▤" },
    { href: "/app/historial", label: "Historial", icon: "✓" },
  ];

  return (
    <>
      <header className="sticky top-0 z-20 bg-[var(--navy)] text-white">
        <div className="flex items-center justify-between px-4 py-3.5">
          <div>
            <div className="font-display uppercase tracking-wide text-base leading-none">
              Mayco Automotive
            </div>
            <div className="text-[11px] text-white/50 mt-0.5">{name}</div>
          </div>
          <button
            onClick={() => signOut({ callbackUrl: "/login" })}
            className="text-xs text-white/70 underline underline-offset-2"
          >
            Salir
          </button>
        </div>
        <div className="hazard-stripe-thin" />
      </header>

      <nav className="fixed bottom-0 inset-x-0 z-20 bg-white border-t border-[var(--line)] flex md:hidden">
        {items.map((item) => {
          const active = pathname.startsWith(item.href);
          return (
            <Link
              key={item.href}
              href={item.href}
              className={`flex-1 flex flex-col items-center gap-0.5 py-2.5 text-[11px] font-medium ${
                active ? "text-[var(--orange)]" : "text-[var(--muted)]"
              }`}
            >
              <span className="text-base leading-none">{item.icon}</span>
              {item.label}
            </Link>
          );
        })}
      </nav>
    </>
  );
}
