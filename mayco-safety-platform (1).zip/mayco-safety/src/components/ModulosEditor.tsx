"use client";

import { useState, useTransition, useRef } from "react";
import { agregarModulo, eliminarModulo } from "@/lib/actions/admin";

type Modulo = {
  id: string;
  title: string;
  type: "texto" | "video" | "pdf" | "imagen";
  content: string;
  order: number;
};

const tipos: { value: Modulo["type"]; label: string }[] = [
  { value: "texto", label: "Texto" },
  { value: "video", label: "Video" },
  { value: "pdf", label: "PDF" },
  { value: "imagen", label: "Imagen" },
];

const acceptByType: Record<Modulo["type"], string> = {
  texto: "",
  video: "video/mp4,video/webm,video/quicktime",
  pdf: "application/pdf",
  imagen: "image/png,image/jpeg,image/webp,image/gif",
};

export default function ModulosEditor({
  courseId,
  modulosIniciales,
}: {
  courseId: string;
  modulosIniciales: Modulo[];
}) {
  const [isPending, startTransition] = useTransition();
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState<{ title: string; type: Modulo["type"]; content: string }>({
    title: "",
    type: "texto",
    content: "",
  });
  const [modoArchivo, setModoArchivo] = useState(true);
  const [subiendo, setSubiendo] = useState(false);
  const [errorSubida, setErrorSubida] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setSubiendo(true);
    setErrorSubida("");
    try {
      const fd = new FormData();
      fd.append("file", file);
      const res = await fetch("/api/upload", { method: "POST", body: fd });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Error al subir el archivo");
      setForm((f) => ({ ...f, content: data.url }));
    } catch (err) {
      setErrorSubida(err instanceof Error ? err.message : "Error al subir el archivo");
    } finally {
      setSubiendo(false);
    }
  };

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    startTransition(async () => {
      await agregarModulo({ courseId, ...form });
      setForm({ title: "", type: "texto", content: "" });
      setErrorSubida("");
      setShowForm(false);
    });
  };

  const handleDelete = (id: string) => {
    startTransition(async () => {
      await eliminarModulo(id, courseId);
    });
  };

  return (
    <div className="space-y-3">
      {modulosIniciales
        .sort((a, b) => a.order - b.order)
        .map((m, i) => (
          <div
            key={m.id}
            className="bg-white border border-[var(--line)] rounded-lg p-3.5 flex items-start gap-3"
          >
            <span className="font-mono text-xs text-[var(--muted)] mt-0.5">{i + 1}</span>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <span className="text-sm font-medium">{m.title}</span>
                <span className="text-[10px] uppercase tracking-wide bg-[var(--bg)] text-[var(--muted)] rounded px-1.5 py-0.5">
                  {m.type}
                </span>
              </div>
              <p className="text-xs text-[var(--muted)] line-clamp-2 mt-0.5">{m.content}</p>
            </div>
            <button
              onClick={() => handleDelete(m.id)}
              disabled={isPending}
              className="text-xs text-[var(--danger)] shrink-0 hover:underline"
            >
              Eliminar
            </button>
          </div>
        ))}

      {!showForm && (
        <button
          onClick={() => setShowForm(true)}
          className="w-full rounded-lg border border-dashed border-[var(--line)] py-3 text-sm text-[var(--muted)] hover:border-[var(--orange)] hover:text-[var(--orange)] transition-colors"
        >
          + Agregar módulo
        </button>
      )}

      {showForm && (
        <form
          onSubmit={handleAdd}
          className="bg-white border border-[var(--line)] rounded-lg p-4 space-y-3"
        >
          <input
            required
            placeholder="Título del módulo"
            value={form.title}
            onChange={(e) => setForm({ ...form, title: e.target.value })}
            className="w-full rounded-md border border-[var(--line)] px-3 py-2 text-sm"
          />
          <div className="flex gap-2">
            {tipos.map((t) => (
              <button
                type="button"
                key={t.value}
                onClick={() => setForm({ ...form, type: t.value, content: "" })}
                className={`text-xs rounded-full px-3 py-1.5 border ${
                  form.type === t.value
                    ? "bg-[var(--navy)] text-white border-[var(--navy)]"
                    : "border-[var(--line)] text-[var(--muted)]"
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>

          {form.type === "texto" ? (
            <textarea
              required
              rows={4}
              placeholder="Escribe el contenido del módulo..."
              value={form.content}
              onChange={(e) => setForm({ ...form, content: e.target.value })}
              className="w-full rounded-md border border-[var(--line)] px-3 py-2 text-sm"
            />
          ) : (
            <div className="space-y-2">
              <div className="flex gap-2 text-xs">
                <button
                  type="button"
                  onClick={() => setModoArchivo(true)}
                  className={`rounded-full px-3 py-1 border ${
                    modoArchivo
                      ? "border-[var(--orange)] text-[var(--orange)]"
                      : "border-[var(--line)] text-[var(--muted)]"
                  }`}
                >
                  Subir archivo
                </button>
                <button
                  type="button"
                  onClick={() => setModoArchivo(false)}
                  className={`rounded-full px-3 py-1 border ${
                    !modoArchivo
                      ? "border-[var(--orange)] text-[var(--orange)]"
                      : "border-[var(--line)] text-[var(--muted)]"
                  }`}
                >
                  Pegar URL
                </button>
              </div>

              {modoArchivo ? (
                <div>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept={acceptByType[form.type]}
                    onChange={handleFileChange}
                    className="w-full text-xs rounded-md border border-[var(--line)] px-3 py-2 file:mr-3 file:rounded-md file:border-0 file:bg-[var(--bg)] file:px-3 file:py-1.5 file:text-xs"
                  />
                  {subiendo && (
                    <p className="text-xs text-[var(--muted)] mt-1">Subiendo archivo...</p>
                  )}
                  {errorSubida && (
                    <p className="text-xs text-[var(--danger)] mt-1">{errorSubida}</p>
                  )}
                  {form.content && !subiendo && (
                    <p className="text-xs text-[var(--success)] mt-1">
                      ✓ Archivo listo: {form.content.split("/").pop()}
                    </p>
                  )}
                </div>
              ) : (
                <input
                  required
                  placeholder="https://..."
                  value={form.content}
                  onChange={(e) => setForm({ ...form, content: e.target.value })}
                  className="w-full rounded-md border border-[var(--line)] px-3 py-2 text-sm"
                />
              )}
            </div>
          )}
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => setShowForm(false)}
              className="flex-1 rounded-md border border-[var(--line)] py-2 text-sm"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={isPending || subiendo || (form.type !== "texto" && !form.content)}
              className="flex-1 rounded-md bg-[var(--navy)] text-white py-2 text-sm disabled:opacity-60"
            >
              {isPending ? "Guardando..." : "Guardar módulo"}
            </button>
          </div>
        </form>
      )}
    </div>
  );
}
