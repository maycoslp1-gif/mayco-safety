"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { enviarExamen } from "@/lib/actions/empleado";

type Opcion = { id: string; text: string };
type Pregunta = {
  id: string;
  prompt: string;
  type: "opcion_unica" | "verdadero_falso";
  options: Opcion[];
};

export default function ExamenForm({
  courseId,
  preguntas,
  passingScore,
}: {
  courseId: string;
  preguntas: Pregunta[];
  passingScore: number;
}) {
  const router = useRouter();
  const [respuestas, setRespuestas] = useState<Record<string, string>>({});
  const [isPending, startTransition] = useTransition();
  const [resultado, setResultado] = useState<{
    score: number;
    passed: boolean;
    total: number;
    correctas: number;
    attemptId: string;
  } | null>(null);

  const todasContestadas = preguntas.every((p) => respuestas[p.id]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    startTransition(async () => {
      const res = await enviarExamen(courseId, respuestas);
      setResultado(res);
    });
  };

  if (resultado) {
    return (
      <div className="text-center bg-white border border-[var(--line)] rounded-xl p-8">
        <div
          className={`w-20 h-20 rounded-full mx-auto flex items-center justify-center font-display text-2xl ${
            resultado.passed
              ? "bg-[var(--success-bg)] text-[var(--success)]"
              : "bg-[var(--danger-bg)] text-[var(--danger)]"
          }`}
        >
          {resultado.score}%
        </div>
        <h2 className="font-display text-xl uppercase tracking-wide mt-4">
          {resultado.passed ? "¡Aprobado!" : "No aprobado"}
        </h2>
        <p className="text-sm text-[var(--muted)] mt-1.5">
          Respondiste correctamente {resultado.correctas} de {resultado.total} preguntas.
          {!resultado.passed && ` Necesitas al menos ${passingScore}% para aprobar.`}
        </p>

        <div className="flex gap-2 mt-6">
          {!resultado.passed && (
            <button
              onClick={() => {
                setRespuestas({});
                setResultado(null);
              }}
              className="flex-1 rounded-md border border-[var(--line)] py-2.5 text-sm font-medium"
            >
              Reintentar examen
            </button>
          )}
          {resultado.passed && (
            <a
              href={`/api/certificado/${resultado.attemptId}`}
              target="_blank"
              rel="noreferrer"
              className="flex-1 text-center rounded-md border border-[var(--navy)] text-[var(--navy)] py-2.5 text-sm font-medium"
            >
              🏆 Descargar certificado
            </a>
          )}
          <button
            onClick={() => router.push("/app/cursos")}
            className="flex-1 rounded-md bg-[var(--orange)] hover:bg-[var(--orange-dark)] text-white py-2.5 text-sm font-semibold"
          >
            Volver a mis cursos
          </button>
        </div>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {preguntas.map((p, i) => (
        <div key={p.id} className="bg-white border border-[var(--line)] rounded-xl p-4">
          <p className="text-sm font-medium mb-3">
            <span className="font-mono text-xs text-[var(--muted)] mr-1.5">{i + 1}.</span>
            {p.prompt}
          </p>
          <div className="space-y-2">
            {p.options.map((o) => (
              <label
                key={o.id}
                className={`flex items-center gap-2.5 rounded-lg border px-3.5 py-2.5 text-sm cursor-pointer transition-colors ${
                  respuestas[p.id] === o.id
                    ? "border-[var(--orange)] bg-orange-50"
                    : "border-[var(--line)]"
                }`}
              >
                <input
                  type="radio"
                  name={p.id}
                  checked={respuestas[p.id] === o.id}
                  onChange={() => setRespuestas({ ...respuestas, [p.id]: o.id })}
                  className="accent-[var(--orange)]"
                />
                {o.text}
              </label>
            ))}
          </div>
        </div>
      ))}

      <button
        type="submit"
        disabled={!todasContestadas || isPending}
        className="w-full rounded-md bg-[var(--orange)] hover:bg-[var(--orange-dark)] text-white font-semibold py-3 text-sm disabled:opacity-40"
      >
        {isPending ? "Calificando..." : "Enviar examen"}
      </button>
      {!todasContestadas && (
        <p className="text-xs text-[var(--muted)] text-center">
          Responde todas las preguntas para poder enviar.
        </p>
      )}
    </form>
  );
}
