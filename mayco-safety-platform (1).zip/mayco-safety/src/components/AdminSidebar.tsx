"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { signOut } from "next-auth/react";

const items = [
  { href: "/admin", label: "Resumen", icon: "▣" },
  { href: "/admin/cursos", label: "Cursos", icon: "▤" },
  { href: "/admin/empleados", label: "Empleados", icon: "◉" },
  { href: "/admin/calificaciones", label: "Calificaciones", icon: "✓" },
];

export default function AdminSidebar({ name }: { name: string }) {
  const pathname = usePathname();

  return (
    <aside className="hidden md:flex md:flex-col w-60 shrink-0 bg-[var(--navy)] text-white min-h-screen">
      <div className="px-5 py-6">
        <div className="font-display uppercase tracking-wide text-lg">Mayco</div>
        <div className="text-xs text-white/50">Panel de administración</div>
      </div>
      <nav className="flex-1 px-3 space-y-1">
        {items.map((item) => {
          const active =
            item.href === "/admin"
              ? pathname === "/admin"
              : pathname.startsWith(item.href);
          return (
            <Link
              key={item.href}
              href={item.href}
              className={`flex items-center gap-3 rounded-md px-3 py-2.5 text-sm transition-colors ${
                active
                  ? "bg-[var(--orange)] text-white font-medium"
                  : "text-white/70 hover:bg-white/10 hover:text-white"
              }`}
            >
              <span className="w-4 text-center">{item.icon}</span>
              {item.label}
            </Link>
          );
        })}
      </nav>
      <div className="px-5 py-5 border-t border-white/10">
        <div className="text-xs text-white/50 mb-2 truncate">{name}</div>
        <button
          onClick={() => signOut({ callbackUrl: "/login" })}
          className="text-xs text-white/70 hover:text-white underline underline-offset-2"
        >
          Cerrar sesión
        </button>
      </div>
    </aside>
  );
}
