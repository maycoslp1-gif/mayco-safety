"use client";

import { useState, useTransition } from "react";
import { asignarCursoAEmpleados } from "@/lib/actions/admin";

type Empleado = { id: string; name: string; area: string | null };

export default function AsignarEmpleados({
  courseId,
  empleados,
  asignadosIds,
}: {
  courseId: string;
  empleados: Empleado[];
  asignadosIds: string[];
}) {
  const [seleccion, setSeleccion] = useState<string[]>([]);
  const [isPending, startTransition] = useTransition();
  const [done, setDone] = useState(false);

  const disponibles = empleados.filter((e) => !asignadosIds.includes(e.id));

  const toggle = (id: string) => {
    setSeleccion((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );
  };

  const handleAsignar = () => {
    startTransition(async () => {
      await asignarCursoAEmpleados(courseId, seleccion);
      setSeleccion([]);
      setDone(true);
      setTimeout(() => setDone(false), 2000);
    });
  };

  if (disponibles.length === 0) {
    return (
      <p className="text-sm text-[var(--muted)]">
        Todos los empleados activos ya tienen este curso asignado.
      </p>
    );
  }

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap gap-2 max-h-48 overflow-y-auto">
        {disponibles.map((e) => (
          <button
            key={e.id}
            onClick={() => toggle(e.id)}
            className={`text-xs rounded-full px-3 py-1.5 border ${
              seleccion.includes(e.id)
                ? "bg-[var(--orange)] text-white border-[var(--orange)]"
                : "border-[var(--line)] text-[var(--muted)]"
            }`}
          >
            {e.name}
            {e.area ? ` · ${e.area}` : ""}
          </button>
        ))}
      </div>
      <button
        onClick={handleAsignar}
        disabled={seleccion.length === 0 || isPending}
        className="rounded-md bg-[var(--navy)] text-white text-sm font-medium px-4 py-2 disabled:opacity-40"
      >
        {isPending ? "Asignando..." : `Asignar a ${seleccion.length || ""} empleado(s)`}
      </button>
      {done && <p className="text-xs text-[var(--success)]">Curso asignado correctamente.</p>}
    </div>
  );
}
