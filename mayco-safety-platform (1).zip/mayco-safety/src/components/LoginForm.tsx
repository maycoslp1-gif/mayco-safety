"use client";

import { useState, useTransition } from "react";
import { signIn } from "next-auth/react";
import { useRouter, useSearchParams } from "next/navigation";

export default function LoginForm() {
  const router = useRouter();
  const params = useSearchParams();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [isPending, startTransition] = useTransition();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    startTransition(async () => {
      const res = await signIn("credentials", {
        email,
        password,
        redirect: false,
      });
      if (res?.error) {
        setError("Correo o contraseña incorrectos.");
        return;
      }
      const from = params.get("from");
      router.push(from || "/app/cursos");
      router.refresh();
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-[var(--muted)] mb-1.5">
          Correo electrónico
        </label>
        <input
          type="email"
          required
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="tucorreo@mayco.com"
          className="w-full rounded-md border border-[var(--line)] bg-white px-3.5 py-2.5 text-[15px] outline-none focus:border-[var(--navy)] focus:ring-2 focus:ring-[var(--navy)]/15"
        />
      </div>
      <div>
        <label className="block text-sm font-medium text-[var(--muted)] mb-1.5">
          Contraseña
        </label>
        <input
          type="password"
          required
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="••••••••"
          className="w-full rounded-md border border-[var(--line)] bg-white px-3.5 py-2.5 text-[15px] outline-none focus:border-[var(--navy)] focus:ring-2 focus:ring-[var(--navy)]/15"
        />
      </div>

      {error && (
        <p className="text-sm text-[var(--danger)] bg-[var(--danger-bg)] rounded-md px-3 py-2">
          {error}
        </p>
      )}

      <button
        type="submit"
        disabled={isPending}
        className="w-full rounded-md bg-[var(--orange)] hover:bg-[var(--orange-dark)] transition-colors text-white font-semibold py-2.5 text-[15px] disabled:opacity-60"
      >
        {isPending ? "Entrando..." : "Entrar"}
      </button>
    </form>
  );
}
