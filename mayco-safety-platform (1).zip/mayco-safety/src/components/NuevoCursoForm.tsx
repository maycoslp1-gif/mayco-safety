"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { crearCurso } from "@/lib/actions/admin";

const colores = [
  { label: "Naranja", value: "#FF6B35" },
  { label: "Acero", value: "#2E5266" },
  { label: "Marino", value: "#0B1F3A" },
  { label: "Verde", value: "#1F8A56" },
];

export default function NuevoCursoForm() {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [isPending, startTransition] = useTransition();
  const [form, setForm] = useState({
    title: "",
    description: "",
    category: "General",
    coverColor: "#FF6B35",
    passingScore: 80,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    startTransition(async () => {
      const curso = await crearCurso(form);
      setOpen(false);
      router.push(`/admin/cursos/${curso.id}`);
    });
  };

  if (!open) {
    return (
      <button
        onClick={() => setOpen(true)}
        className="rounded-md bg-[var(--orange)] hover:bg-[var(--orange-dark)] text-white text-sm font-medium px-4 py-2.5"
      >
        + Nuevo curso
      </button>
    );
  }

  return (
    <div className="fixed inset-0 bg-black/40 flex items-end md:items-center justify-center z-50 p-0 md:p-4">
      <form
        onSubmit={handleSubmit}
        className="bg-white w-full md:max-w-md rounded-t-2xl md:rounded-xl p-5 space-y-4 max-h-[90vh] overflow-y-auto"
      >
        <h2 className="font-display text-lg uppercase tracking-wide">Nuevo curso</h2>

        <div>
          <label className="block text-xs font-medium text-[var(--muted)] mb-1">Título</label>
          <input
            required
            value={form.title}
            onChange={(e) => setForm({ ...form, title: e.target.value })}
            placeholder="Ej. Uso correcto de EPP"
            className="w-full rounded-md border border-[var(--line)] px-3 py-2 text-sm"
          />
        </div>

        <div>
          <label className="block text-xs font-medium text-[var(--muted)] mb-1">Descripción</label>
          <textarea
            required
            value={form.description}
            onChange={(e) => setForm({ ...form, description: e.target.value })}
            rows={3}
            placeholder="Breve descripción del curso y a quién va dirigido"
            className="w-full rounded-md border border-[var(--line)] px-3 py-2 text-sm"
          />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-medium text-[var(--muted)] mb-1">Categoría</label>
            <input
              value={form.category}
              onChange={(e) => setForm({ ...form, category: e.target.value })}
              placeholder="Ej. Incendios, EPP, NOMs"
              className="w-full rounded-md border border-[var(--line)] px-3 py-2 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-[var(--muted)] mb-1">
              % mínimo aprobatorio
            </label>
            <input
              type="number"
              min={0}
              max={100}
              value={form.passingScore}
              onChange={(e) => setForm({ ...form, passingScore: Number(e.target.value) })}
              className="w-full rounded-md border border-[var(--line)] px-3 py-2 text-sm"
            />
          </div>
        </div>

        <div>
          <label className="block text-xs font-medium text-[var(--muted)] mb-1.5">Color</label>
          <div className="flex gap-2">
            {colores.map((c) => (
              <button
                type="button"
                key={c.value}
                onClick={() => setForm({ ...form, coverColor: c.value })}
                className={`w-8 h-8 rounded-full border-2 ${
                  form.coverColor === c.value ? "border-[var(--ink)]" : "border-transparent"
                }`}
                style={{ background: c.value }}
                title={c.label}
              />
            ))}
          </div>
        </div>

        <div className="flex gap-2 pt-2">
          <button
            type="button"
            onClick={() => setOpen(false)}
            className="flex-1 rounded-md border border-[var(--line)] py-2.5 text-sm font-medium"
          >
            Cancelar
          </button>
          <button
            type="submit"
            disabled={isPending}
            className="flex-1 rounded-md bg-[var(--orange)] hover:bg-[var(--orange-dark)] text-white py-2.5 text-sm font-medium disabled:opacity-60"
          >
            {isPending ? "Creando..." : "Crear curso"}
          </button>
        </div>
      </form>
    </div>
  );
}
