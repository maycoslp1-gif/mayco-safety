import { DefaultSession } from "next-auth";

declare module "next-auth" {
  interface Session {
    user: {
      id: string;
      role: "admin" | "empleado";
    } & DefaultSession["user"];
  }
  interface User {
    role?: "admin" | "empleado";
  }
}
