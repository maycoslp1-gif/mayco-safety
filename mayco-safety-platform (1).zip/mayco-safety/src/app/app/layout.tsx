import { auth } from "@/lib/auth";
import AppNav from "@/components/AppNav";

export default async function EmployeeAppLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const session = await auth();

  return (
    <div className="min-h-screen pb-20 md:pb-0">
      <AppNav name={session?.user?.name || ""} />
      <div className="px-4 py-5 md:px-8 md:py-8 max-w-3xl mx-auto">{children}</div>
    </div>
  );
}
