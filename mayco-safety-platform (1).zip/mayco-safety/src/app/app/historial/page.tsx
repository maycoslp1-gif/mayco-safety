import { db } from "@/db";
import { examAttempts } from "@/db/schema";
import { eq } from "drizzle-orm";
import { auth } from "@/lib/auth";

export default async function HistorialPage() {
  const session = await auth();
  if (!session) return null;

  const intentos = await db.query.examAttempts.findMany({
    where: eq(examAttempts.userId, session.user.id),
    orderBy: (t, { desc }) => desc(t.takenAt),
    with: { course: true },
  });

  return (
    <div>
      <header className="mb-5">
        <h1 className="font-display text-2xl uppercase tracking-wide">Mi historial</h1>
        <p className="text-sm text-[var(--muted)]">
          Tus exámenes y calificaciones de capacitación.
        </p>
      </header>

      {intentos.length === 0 && (
        <div className="bg-white border border-dashed border-[var(--line)] rounded-xl p-8 text-center">
          <p className="text-sm text-[var(--muted)]">
            Todavía no has presentado ningún examen.
          </p>
        </div>
      )}

      <div className="space-y-2.5">
        {intentos.map((a) => (
          <div
            key={a.id}
            className="bg-white border border-[var(--line)] rounded-xl p-4 flex items-center justify-between gap-3"
          >
            <div className="min-w-0">
              <p className="text-sm font-medium truncate">{a.course.title}</p>
              <p className="text-xs text-[var(--muted)] font-mono mt-0.5">
                {new Date(a.takenAt + "Z").toLocaleString("es-MX", {
                  dateStyle: "medium",
                  timeStyle: "short",
                })}
              </p>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <span className="font-mono font-semibold text-sm">{a.score}%</span>
              <span
                className={`text-[10px] uppercase tracking-wide rounded-full px-2 py-0.5 ${
                  a.passed
                    ? "bg-[var(--success-bg)] text-[var(--success)]"
                    : "bg-[var(--danger-bg)] text-[var(--danger)]"
                }`}
              >
                {a.passed ? "Aprobado" : "No aprobado"}
              </span>
              {a.passed && (
                <a
                  href={`/api/certificado/${a.id}`}
                  target="_blank"
                  rel="noreferrer"
                  title="Descargar certificado"
                  className="text-base"
                >
                  🏆
                </a>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
