import { db } from "@/db";
import { enrollments } from "@/db/schema";
import { eq } from "drizzle-orm";
import { auth } from "@/lib/auth";
import Link from "next/link";

const statusLabel: Record<string, string> = {
  pendiente: "Pendiente",
  en_progreso: "En progreso",
  completado: "Completado",
};

export default async function MisCursosPage() {
  const session = await auth();
  if (!session) return null;

  const misCursos = await db.query.enrollments.findMany({
    where: eq(enrollments.userId, session.user.id),
    with: { course: true },
    orderBy: (t, { asc }) => asc(t.status),
  });

  return (
    <div>
      <header className="mb-5">
        <h1 className="font-display text-2xl uppercase tracking-wide">Mis cursos</h1>
        <p className="text-sm text-[var(--muted)]">
          Capacitación de seguridad asignada para ti.
        </p>
      </header>

      {misCursos.length === 0 && (
        <div className="bg-white border border-dashed border-[var(--line)] rounded-xl p-8 text-center">
          <p className="text-sm text-[var(--muted)]">
            Todavía no tienes cursos asignados. Tu coordinador de seguridad te asignará uno pronto.
          </p>
        </div>
      )}

      <div className="space-y-3">
        {misCursos.map((en) => (
          <Link
            key={en.id}
            href={`/app/cursos/${en.courseId}`}
            className="block bg-white border border-[var(--line)] rounded-xl overflow-hidden hover:shadow-md transition-shadow"
          >
            <div className="h-1.5" style={{ background: en.course.coverColor }} />
            <div className="p-4">
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-[10px] uppercase tracking-wider font-semibold text-[var(--muted)]">
                  {en.course.category}
                </span>
                <span
                  className={`text-[10px] uppercase tracking-wide rounded-full px-2 py-0.5 font-mono ${
                    en.status === "completado"
                      ? "bg-[var(--success-bg)] text-[var(--success)]"
                      : en.status === "en_progreso"
                      ? "bg-amber-100 text-amber-700"
                      : "bg-[var(--bg)] text-[var(--muted)]"
                  }`}
                >
                  {statusLabel[en.status]}
                </span>
              </div>
              <h3 className="font-display text-lg leading-tight mb-2">{en.course.title}</h3>
              <div className="w-full h-1.5 bg-[var(--bg)] rounded-full overflow-hidden">
                <div
                  className="h-full bg-[var(--orange)] transition-all"
                  style={{ width: `${en.progressPct}%` }}
                />
              </div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
