import { db } from "@/db";
import { courses, enrollments } from "@/db/schema";
import { eq, and } from "drizzle-orm";
import { notFound, redirect } from "next/navigation";
import { auth } from "@/lib/auth";
import Link from "next/link";
import ModuloViewer from "@/components/ModuloViewer";

export default async function CursoEmpleadoPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const session = await auth();
  if (!session) redirect("/login");

  const curso = await db.query.courses.findFirst({
    where: eq(courses.id, id),
    with: { modules: true, questions: true },
  });
  if (!curso) notFound();

  const inscripcion = await db.query.enrollments.findFirst({
    where: and(eq(enrollments.courseId, id), eq(enrollments.userId, session.user.id)),
  });
  if (!inscripcion) notFound();

  return (
    <div>
      <Link href="/app/cursos" className="text-xs text-[var(--muted)] hover:underline">
        ← Mis cursos
      </Link>
      <header className="mb-4 mt-1">
        <span className="text-[10px] uppercase tracking-wider font-semibold text-[var(--muted)]">
          {curso.category}
        </span>
        <h1 className="font-display text-2xl uppercase tracking-wide">{curso.title}</h1>
        <p className="text-sm text-[var(--muted)] mt-1">{curso.description}</p>
      </header>

      <ModuloViewer
        courseId={curso.id}
        modulos={curso.modules}
        hasExam={curso.questions.length > 0}
        yaCompletado={inscripcion.status === "completado"}
      />
    </div>
  );
}
