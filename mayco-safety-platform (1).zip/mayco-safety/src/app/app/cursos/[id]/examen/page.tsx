import { db } from "@/db";
import { courses } from "@/db/schema";
import { eq } from "drizzle-orm";
import { notFound } from "next/navigation";
import Link from "next/link";
import ExamenForm from "@/components/ExamenForm";

export default async function ExamenEmpleadoPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;

  const curso = await db.query.courses.findFirst({
    where: eq(courses.id, id),
    with: {
      questions: { with: { options: true } },
    },
  });
  if (!curso) notFound();

  // No enviamos isCorrect al cliente.
  const preguntas = curso.questions
    .sort((a, b) => a.order - b.order)
    .map((p) => ({
      id: p.id,
      prompt: p.prompt,
      type: p.type,
      options: p.options
        .sort((a, b) => a.order - b.order)
        .map((o) => ({ id: o.id, text: o.text })),
    }));

  if (preguntas.length === 0) {
    return (
      <div className="bg-white border border-dashed border-[var(--line)] rounded-xl p-8 text-center text-sm text-[var(--muted)]">
        Este curso todavía no tiene examen configurado.
      </div>
    );
  }

  return (
    <div>
      <Link
        href={`/app/cursos/${id}`}
        className="text-xs text-[var(--muted)] hover:underline"
      >
        ← Volver al curso
      </Link>
      <header className="mb-4 mt-1">
        <h1 className="font-display text-2xl uppercase tracking-wide">Examen final</h1>
        <p className="text-sm text-[var(--muted)]">
          {curso.title} · Necesitas {curso.passingScore}% para aprobar.
        </p>
      </header>

      <ExamenForm courseId={id} preguntas={preguntas} passingScore={curso.passingScore} />
    </div>
  );
}
