import LoginForm from "@/components/LoginForm";
import { Suspense } from "react";

export default function LoginPage() {
  return (
    <main className="min-h-screen flex flex-col">
      <div className="bg-[var(--navy)] text-white px-6 py-10 flex flex-col items-center text-center">
        <span className="font-display text-2xl tracking-wide uppercase">
          Mayco Automotive
        </span>
        <span className="text-sm text-white/60 mt-1">
          Plataforma de Capacitación en Seguridad
        </span>
      </div>
      <div className="hazard-stripe" />

      <div className="flex-1 flex items-start justify-center px-5 py-10">
        <div className="w-full max-w-sm bg-white rounded-xl border border-[var(--line)] shadow-sm p-6">
          <h1 className="font-display text-xl uppercase tracking-wide mb-1">
            Iniciar sesión
          </h1>
          <p className="text-sm text-[var(--muted)] mb-6">
            Usa las credenciales que te asignó tu coordinador de seguridad.
          </p>
          <Suspense>
            <LoginForm />
          </Suspense>
        </div>
      </div>

      <div className="text-center text-xs text-[var(--muted)] pb-6">
        ¿Problemas para entrar? Contacta a Recursos Humanos.
      </div>
    </main>
  );
}
