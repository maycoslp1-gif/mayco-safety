import { db } from "@/db";
import { courses, users, enrollments, examAttempts } from "@/db/schema";
import { eq, sql } from "drizzle-orm";
import Link from "next/link";

export default async function AdminHome() {
  const [{ totalCursos }] = await db
    .select({ totalCursos: sql<number>`count(*)` })
    .from(courses);
  const [{ totalEmpleados }] = await db
    .select({ totalEmpleados: sql<number>`count(*)` })
    .from(users)
    .where(eq(users.role, "empleado"));
  const [{ totalCompletados }] = await db
    .select({ totalCompletados: sql<number>`count(*)` })
    .from(enrollments)
    .where(eq(enrollments.status, "completado"));
  const [{ promedio }] = await db
    .select({ promedio: sql<number>`avg(score)` })
    .from(examAttempts);

  const intentosRecientes = await db.query.examAttempts.findMany({
    orderBy: (t, { desc }) => desc(t.takenAt),
    limit: 6,
    with: { user: true, course: true },
  });

  const stats = [
    { label: "Cursos activos", value: totalCursos, href: "/admin/cursos" },
    { label: "Empleados registrados", value: totalEmpleados, href: "/admin/empleados" },
    { label: "Cursos completados", value: totalCompletados, href: "/admin/calificaciones" },
    {
      label: "Promedio de examen",
      value: promedio ? `${Math.round(promedio)}%` : "—",
      href: "/admin/calificaciones",
    },
  ];

  return (
    <div>
      <header className="mb-6">
        <h1 className="font-display text-2xl uppercase tracking-wide">Resumen general</h1>
        <p className="text-sm text-[var(--muted)]">
          Estado de la capacitación en seguridad de la planta.
        </p>
      </header>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-8">
        {stats.map((s) => (
          <Link
            key={s.label}
            href={s.href}
            className="bg-white border border-[var(--line)] rounded-xl p-4 hover:border-[var(--orange)] transition-colors"
          >
            <div className="text-2xl font-display">{s.value}</div>
            <div className="text-xs text-[var(--muted)] mt-1">{s.label}</div>
          </Link>
        ))}
      </div>

      <section>
        <h2 className="font-display text-lg uppercase tracking-wide mb-3">
          Exámenes recientes
        </h2>
        <div className="bg-white border border-[var(--line)] rounded-xl overflow-hidden">
          {intentosRecientes.length === 0 && (
            <p className="p-5 text-sm text-[var(--muted)]">
              Aún no hay exámenes registrados.
            </p>
          )}
          {intentosRecientes.map((a) => (
            <div
              key={a.id}
              className="flex items-center justify-between px-4 py-3 border-b last:border-0 border-[var(--line)]"
            >
              <div className="min-w-0">
                <div className="text-sm font-medium truncate">{a.user.name}</div>
                <div className="text-xs text-[var(--muted)] truncate">{a.course.title}</div>
              </div>
              <span
                className={`shrink-0 ml-3 text-xs font-mono font-semibold rounded-full px-2.5 py-1 ${
                  a.passed
                    ? "bg-[var(--success-bg)] text-[var(--success)]"
                    : "bg-[var(--danger-bg)] text-[var(--danger)]"
                }`}
              >
                {a.score}%
              </span>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
