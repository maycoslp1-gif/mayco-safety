import { db } from "@/db";
import { users } from "@/db/schema";
import { eq, sql } from "drizzle-orm";
import NuevoEmpleadoForm from "@/components/NuevoEmpleadoForm";
import EstadoEmpleadoToggle from "@/components/EstadoEmpleadoToggle";

export default async function EmpleadosPage() {
  const empleados = await db.query.users.findMany({
    where: eq(users.role, "empleado"),
    orderBy: (t, { desc }) => desc(t.createdAt),
    with: { enrollments: true },
  });

  return (
    <div>
      <header className="mb-6 flex items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl uppercase tracking-wide">Empleados</h1>
          <p className="text-sm text-[var(--muted)]">
            Administra las cuentas del personal de planta.
          </p>
        </div>
        <NuevoEmpleadoForm />
      </header>

      <div className="bg-white border border-[var(--line)] rounded-xl overflow-hidden">
        <div className="hidden md:grid grid-cols-[1.5fr_1fr_1fr_0.8fr_0.6fr] gap-3 px-4 py-2.5 text-[11px] uppercase tracking-wide text-[var(--muted)] font-semibold border-b border-[var(--line)]">
          <span>Nombre</span>
          <span>Área</span>
          <span>Puesto</span>
          <span>Cursos</span>
          <span>Estado</span>
        </div>
        {empleados.length === 0 && (
          <p className="p-6 text-sm text-[var(--muted)]">Aún no hay empleados registrados.</p>
        )}
        {empleados.map((e) => {
          const completados = e.enrollments.filter((en) => en.status === "completado").length;
          return (
            <div
              key={e.id}
              className="grid grid-cols-2 md:grid-cols-[1.5fr_1fr_1fr_0.8fr_0.6fr] gap-2 md:gap-3 px-4 py-3 border-b last:border-0 border-[var(--line)] items-center text-sm"
            >
              <div>
                <div className="font-medium">{e.name}</div>
                <div className="text-xs text-[var(--muted)] md:hidden">{e.email}</div>
              </div>
              <span className="hidden md:inline text-[var(--muted)]">{e.area || "—"}</span>
              <span className="hidden md:inline text-[var(--muted)]">{e.puesto || "—"}</span>
              <span className="font-mono text-xs text-[var(--muted)]">
                {completados}/{e.enrollments.length}
              </span>
              <EstadoEmpleadoToggle id={e.id} activo={e.activo} />
            </div>
          );
        })}
      </div>
    </div>
  );
}
