import { auth } from "@/lib/auth";
import AdminSidebar from "@/components/AdminSidebar";
import AdminMobileNav from "@/components/AdminMobileNav";

export default async function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const session = await auth();

  return (
    <div className="flex min-h-screen">
      <AdminSidebar name={session?.user?.name || ""} />
      <div className="flex-1 min-w-0">
        <AdminMobileNav />
        <div className="p-5 md:p-8 max-w-6xl mx-auto">{children}</div>
      </div>
    </div>
  );
}
