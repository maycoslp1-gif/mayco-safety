import { db } from "@/db";

export default async function CalificacionesPage() {
  const intentos = await db.query.examAttempts.findMany({
    orderBy: (t, { desc }) => desc(t.takenAt),
    with: { user: true, course: true },
  });

  return (
    <div>
      <header className="mb-6">
        <h1 className="font-display text-2xl uppercase tracking-wide">Calificaciones</h1>
        <p className="text-sm text-[var(--muted)]">
          Historial completo de exámenes presentados por los empleados.
        </p>
      </header>

      <div className="bg-white border border-[var(--line)] rounded-xl overflow-hidden">
        <div className="hidden md:grid grid-cols-[1.3fr_1.3fr_0.7fr_0.7fr_1fr] gap-3 px-4 py-2.5 text-[11px] uppercase tracking-wide text-[var(--muted)] font-semibold border-b border-[var(--line)]">
          <span>Empleado</span>
          <span>Curso</span>
          <span>Calificación</span>
          <span>Resultado</span>
          <span>Fecha</span>
        </div>

        {intentos.length === 0 && (
          <p className="p-6 text-sm text-[var(--muted)]">Aún no hay exámenes presentados.</p>
        )}

        {intentos.map((a) => (
          <div
            key={a.id}
            className="grid grid-cols-2 md:grid-cols-[1.3fr_1.3fr_0.7fr_0.7fr_1fr] gap-2 md:gap-3 px-4 py-3 border-b last:border-0 border-[var(--line)] items-center text-sm"
          >
            <span className="font-medium">{a.user.name}</span>
            <span className="text-[var(--muted)]">{a.course.title}</span>
            <span className="font-mono font-semibold">{a.score}%</span>
            <span
              className={`text-[10px] uppercase tracking-wide rounded-full px-2 py-0.5 w-fit ${
                a.passed
                  ? "bg-[var(--success-bg)] text-[var(--success)]"
                  : "bg-[var(--danger-bg)] text-[var(--danger)]"
              }`}
            >
              {a.passed ? "Aprobado" : "No aprobado"}
            </span>
            <span className="text-xs text-[var(--muted)] font-mono">
              {new Date(a.takenAt + "Z").toLocaleString("es-MX", {
                dateStyle: "medium",
                timeStyle: "short",
              })}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
