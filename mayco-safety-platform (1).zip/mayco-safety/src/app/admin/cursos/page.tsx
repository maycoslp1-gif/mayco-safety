import { db } from "@/db";
import Link from "next/link";
import NuevoCursoForm from "@/components/NuevoCursoForm";

export default async function CursosAdminPage() {
  const cursos = await db.query.courses.findMany({
    orderBy: (t, { desc }) => desc(t.createdAt),
    with: {
      modules: true,
      questions: true,
      enrollments: true,
    },
  });

  return (
    <div>
      <header className="mb-6 flex items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl uppercase tracking-wide">Cursos</h1>
          <p className="text-sm text-[var(--muted)]">
            Crea, edita y publica los cursos de capacitación.
          </p>
        </div>
        <NuevoCursoForm />
      </header>

      {cursos.length === 0 && (
        <div className="bg-white border border-dashed border-[var(--line)] rounded-xl p-10 text-center">
          <p className="text-[var(--muted)] text-sm">
            Todavía no hay cursos. Crea el primero para empezar.
          </p>
        </div>
      )}

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {cursos.map((c) => {
          const completados = c.enrollments.filter((e) => e.status === "completado").length;
          return (
            <Link
              key={c.id}
              href={`/admin/cursos/${c.id}`}
              className="bg-white border border-[var(--line)] rounded-xl overflow-hidden hover:shadow-md transition-shadow"
            >
              <div className="h-1.5" style={{ background: c.coverColor }} />
              <div className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] uppercase tracking-wider font-semibold text-[var(--muted)]">
                    {c.category}
                  </span>
                  {!c.published && (
                    <span className="text-[10px] uppercase tracking-wider font-semibold bg-amber-100 text-amber-700 rounded px-1.5 py-0.5">
                      Borrador
                    </span>
                  )}
                </div>
                <h3 className="font-display text-lg leading-tight mb-1.5">{c.title}</h3>
                <p className="text-xs text-[var(--muted)] line-clamp-2 mb-3">{c.description}</p>
                <div className="flex items-center gap-4 text-xs text-[var(--muted)] font-mono">
                  <span>{c.modules.length} módulos</span>
                  <span>{c.questions.length} preguntas</span>
                  <span>{completados}/{c.enrollments.length} completado</span>
                </div>
              </div>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
