import { db } from "@/db";
import { courses, users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { notFound } from "next/navigation";
import Link from "next/link";
import ModulosEditor from "@/components/ModulosEditor";
import AsignarEmpleados from "@/components/AsignarEmpleados";
import CursoAcciones from "@/components/CursoAcciones";

export default async function CursoDetalleAdmin({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;

  const curso = await db.query.courses.findFirst({
    where: eq(courses.id, id),
    with: {
      modules: true,
      questions: true,
      enrollments: { with: { user: true } },
    },
  });

  if (!curso) notFound();

  const empleados = await db
    .select({ id: users.id, name: users.name, area: users.area })
    .from(users)
    .where(eq(users.role, "empleado"));

  return (
    <div className="space-y-8 pb-10">
      <header>
        <Link href="/admin/cursos" className="text-xs text-[var(--muted)] hover:underline">
          ← Volver a cursos
        </Link>
        <div className="flex items-start justify-between gap-3 mt-2">
          <div>
            <span className="text-[10px] uppercase tracking-wider font-semibold text-[var(--muted)]">
              {curso.category}
            </span>
            <h1 className="font-display text-2xl uppercase tracking-wide">{curso.title}</h1>
            <p className="text-sm text-[var(--muted)] mt-1 max-w-xl">{curso.description}</p>
          </div>
          <CursoAcciones courseId={curso.id} published={curso.published} />
        </div>
      </header>

      <section>
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-display text-lg uppercase tracking-wide">Contenido del curso</h2>
          <Link
            href={`/admin/cursos/${curso.id}/examen`}
            className="text-sm text-[var(--navy)] font-medium hover:underline"
          >
            Editar examen ({curso.questions.length} preguntas) →
          </Link>
        </div>
        <ModulosEditor courseId={curso.id} modulosIniciales={curso.modules} />
      </section>

      <section>
        <h2 className="font-display text-lg uppercase tracking-wide mb-3">
          Empleados asignados ({curso.enrollments.length})
        </h2>
        <div className="bg-white border border-[var(--line)] rounded-xl p-4 mb-4">
          {curso.enrollments.length === 0 && (
            <p className="text-sm text-[var(--muted)]">Aún no hay empleados asignados.</p>
          )}
          <div className="space-y-2">
            {curso.enrollments.map((en) => (
              <div
                key={en.id}
                className="flex items-center justify-between text-sm border-b last:border-0 border-[var(--line)] py-2"
              >
                <span>{en.user.name}</span>
                <div className="flex items-center gap-2">
                  <div className="w-24 h-1.5 bg-[var(--bg)] rounded-full overflow-hidden">
                    <div
                      className="h-full bg-[var(--orange)]"
                      style={{ width: `${en.progressPct}%` }}
                    />
                  </div>
                  <span
                    className={`text-[10px] font-mono uppercase rounded-full px-2 py-0.5 ${
                      en.status === "completado"
                        ? "bg-[var(--success-bg)] text-[var(--success)]"
                        : en.status === "en_progreso"
                        ? "bg-amber-100 text-amber-700"
                        : "bg-[var(--bg)] text-[var(--muted)]"
                    }`}
                  >
                    {en.status.replace("_", " ")}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <h3 className="text-sm font-medium mb-2">Asignar a más empleados</h3>
        <AsignarEmpleados
          courseId={curso.id}
          empleados={empleados}
          asignadosIds={curso.enrollments.map((e) => e.userId)}
        />
      </section>
    </div>
  );
}
