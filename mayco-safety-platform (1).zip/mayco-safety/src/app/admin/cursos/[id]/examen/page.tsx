import { db } from "@/db";
import { courses } from "@/db/schema";
import { eq } from "drizzle-orm";
import { notFound } from "next/navigation";
import Link from "next/link";
import ExamenEditor from "@/components/ExamenEditor";

export default async function ExamenAdminPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;

  const curso = await db.query.courses.findFirst({
    where: eq(courses.id, id),
    with: {
      questions: { with: { options: true } },
    },
  });

  if (!curso) notFound();

  return (
    <div className="space-y-6 pb-10">
      <header>
        <Link href={`/admin/cursos/${id}`} className="text-xs text-[var(--muted)] hover:underline">
          ← Volver al curso
        </Link>
        <h1 className="font-display text-2xl uppercase tracking-wide mt-1">
          Examen · {curso.title}
        </h1>
        <p className="text-sm text-[var(--muted)]">
          Los empleados necesitan {curso.passingScore}% o más para aprobar.
        </p>
      </header>

      <ExamenEditor
        courseId={curso.id}
        preguntasIniciales={curso.questions.sort((a, b) => a.order - b.order)}
      />
    </div>
  );
}
