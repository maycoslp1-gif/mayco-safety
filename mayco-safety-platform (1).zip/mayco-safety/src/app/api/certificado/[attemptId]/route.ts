import { NextRequest, NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { db } from "@/db";
import { examAttempts } from "@/db/schema";
import { eq } from "drizzle-orm";
import { PDFDocument, rgb, StandardFonts } from "pdf-lib";

export const runtime = "nodejs";

const NAVY = rgb(11 / 255, 31 / 255, 58 / 255);
const ORANGE = rgb(255 / 255, 107 / 255, 53 / 255);
const CAUTION = rgb(255 / 255, 193 / 255, 7 / 255);
const INK = rgb(22 / 255, 33 / 255, 46 / 255);
const MUTED = rgb(91 / 255, 107 / 255, 122 / 255);

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ attemptId: string }> }
) {
  const session = await auth();
  if (!session) {
    return NextResponse.json({ error: "No autorizado" }, { status: 401 });
  }

  const { attemptId } = await params;

  const attempt = await db.query.examAttempts.findFirst({
    where: eq(examAttempts.id, attemptId),
    with: { user: true, course: true },
  });

  if (!attempt) {
    return NextResponse.json({ error: "No encontrado" }, { status: 404 });
  }

  // Solo el propio empleado o un admin pueden descargar el certificado
  if (attempt.userId !== session.user.id && session.user.role !== "admin") {
    return NextResponse.json({ error: "No autorizado" }, { status: 403 });
  }

  if (!attempt.passed) {
    return NextResponse.json(
      { error: "Este intento no fue aprobado, no se puede generar certificado" },
      { status: 400 }
    );
  }

  const pdfDoc = await PDFDocument.create();
  const page = pdfDoc.addPage([842, 595]); // A4 horizontal
  const { width, height } = page.getSize();

  const fontBold = await pdfDoc.embedFont(StandardFonts.HelveticaBold);
  const fontRegular = await pdfDoc.embedFont(StandardFonts.Helvetica);
  const fontMono = await pdfDoc.embedFont(StandardFonts.Courier);

  // Fondo
  page.drawRectangle({ x: 0, y: 0, width, height, color: rgb(1, 1, 1) });

  // Barra superior navy
  page.drawRectangle({ x: 0, y: height - 70, width, height: 70, color: NAVY });

  // Franja de "hazard stripe" decorativa, delgada, debajo de la barra
  const stripeY = height - 76;
  const stripeH = 6;
  const stripeW = 18;
  let sx = 0;
  let toggle = true;
  while (sx < width) {
    page.drawRectangle({
      x: sx,
      y: stripeY,
      width: stripeW,
      height: stripeH,
      color: toggle ? CAUTION : NAVY,
    });
    sx += stripeW;
    toggle = !toggle;
  }

  page.drawText("MAYCO AUTOMOTIVE", {
    x: 50,
    y: height - 45,
    size: 18,
    font: fontBold,
    color: rgb(1, 1, 1),
  });
  page.drawText("PLATAFORMA DE CAPACITACIÓN EN SEGURIDAD", {
    x: 50,
    y: height - 62,
    size: 8,
    font: fontRegular,
    color: rgb(1, 1, 1),
  });

  // Borde decorativo
  page.drawRectangle({
    x: 30,
    y: 30,
    width: width - 60,
    height: height - 140,
    borderColor: NAVY,
    borderWidth: 1.5,
  });
  page.drawRectangle({
    x: 38,
    y: 38,
    width: width - 76,
    height: height - 156,
    borderColor: ORANGE,
    borderWidth: 0.75,
  });

  const centerX = width / 2;

  const title = "CERTIFICADO DE CAPACITACIÓN";
  const titleSize = 26;
  const titleWidth = fontBold.widthOfTextAtSize(title, titleSize);
  page.drawText(title, {
    x: centerX - titleWidth / 2,
    y: height - 175,
    size: titleSize,
    font: fontBold,
    color: NAVY,
  });

  const sub = "Se otorga el presente reconocimiento a:";
  const subSize = 12;
  const subWidth = fontRegular.widthOfTextAtSize(sub, subSize);
  page.drawText(sub, {
    x: centerX - subWidth / 2,
    y: height - 215,
    size: subSize,
    font: fontRegular,
    color: MUTED,
  });

  const nameSize = 30;
  const nameWidth = fontBold.widthOfTextAtSize(attempt.user.name, nameSize);
  page.drawText(attempt.user.name, {
    x: centerX - nameWidth / 2,
    y: height - 260,
    size: nameSize,
    font: fontBold,
    color: ORANGE,
  });

  const line2 = "por haber completado satisfactoriamente el curso:";
  const line2Width = fontRegular.widthOfTextAtSize(line2, subSize);
  page.drawText(line2, {
    x: centerX - line2Width / 2,
    y: height - 300,
    size: subSize,
    font: fontRegular,
    color: MUTED,
  });

  const courseSize = 19;
  const courseWidth = fontBold.widthOfTextAtSize(attempt.course.title, courseSize);
  page.drawText(attempt.course.title, {
    x: centerX - courseWidth / 2,
    y: height - 332,
    size: courseSize,
    font: fontBold,
    color: INK,
  });

  const fecha = new Date(attempt.takenAt + "Z").toLocaleDateString("es-MX", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });
  const detalle = `Calificación obtenida: ${attempt.score}%   ·   Fecha: ${fecha}`;
  const detalleSize = 11;
  const detalleWidth = fontRegular.widthOfTextAtSize(detalle, detalleSize);
  page.drawText(detalle, {
    x: centerX - detalleWidth / 2,
    y: height - 365,
    size: detalleSize,
    font: fontRegular,
    color: MUTED,
  });

  // Firma / sello
  page.drawLine({
    start: { x: centerX - 110, y: 95 },
    end: { x: centerX + 110, y: 95 },
    thickness: 1,
    color: MUTED,
  });
  const firmaTxt = "Coordinación de Seguridad e Higiene";
  const firmaWidth = fontRegular.widthOfTextAtSize(firmaTxt, 10);
  page.drawText(firmaTxt, {
    x: centerX - firmaWidth / 2,
    y: 80,
    size: 10,
    font: fontRegular,
    color: MUTED,
  });

  // Folio de verificación
  const folio = `Folio: ${attempt.id.slice(0, 8).toUpperCase()}`;
  page.drawText(folio, {
    x: 55,
    y: 50,
    size: 9,
    font: fontMono,
    color: MUTED,
  });

  const pdfBytes = await pdfDoc.save();

  return new NextResponse(Buffer.from(pdfBytes), {
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": `inline; filename="certificado-${attempt.course.title
        .toLowerCase()
        .replace(/\s+/g, "-")}.pdf"`,
    },
  });
}
