import { db } from "./index";
import { users, courses, modules, questions, options, enrollments } from "./schema";
import bcrypt from "bcryptjs";

async function main() {
  console.log("Sembrando base de datos...");

  const adminPass = await bcrypt.hash("Admin123!", 10);
  const empPass = await bcrypt.hash("Empleado123!", 10);

  const [admin] = await db
    .insert(users)
    .values({
      name: "Administrador Mayco",
      email: "admin@mayco.com",
      passwordHash: adminPass,
      role: "admin",
      puesto: "Coordinador de Seguridad e Higiene",
    })
    .returning();

  const [empleado] = await db
    .insert(users)
    .values({
      name: "Juan Pérez",
      email: "empleado@mayco.com",
      passwordHash: empPass,
      role: "empleado",
      area: "Producción",
      puesto: "Operador de línea",
    })
    .returning();

  const [curso] = await db
    .insert(courses)
    .values({
      title: "Seguridad Contra Incendios",
      description:
        "Curso introductorio sobre prevención, clasificación de incendios, uso de extintores y procedimientos de evacuación conforme a NOM-002-STPS-2010.",
      category: "Incendios",
      coverColor: "#FF6B35",
      passingScore: 80,
      published: true,
      createdById: admin.id,
    })
    .returning();

  await db.insert(modules).values([
    {
      courseId: curso.id,
      title: "Introducción y clasificación de incendios",
      type: "texto",
      order: 1,
      content:
        "Los incendios se clasifican en Clase A (materiales sólidos), Clase B (líquidos inflamables), Clase C (equipos eléctricos energizados) y Clase D (metales combustibles). Conocer la clase de incendio es fundamental para elegir el agente extintor correcto y evitar poner en riesgo al personal.",
    },
    {
      courseId: curso.id,
      title: "Uso correcto del extintor (método PASS)",
      type: "texto",
      order: 2,
      content:
        "El método PASS resume el procedimiento: Presionar el seguro, Apuntar a la base del fuego, presionar la palanca para Sacar el agente extintor, y mover en forma de Suave barrido. Verifica mensualmente que tu extintor tenga la presión adecuada según el manómetro.",
    },
    {
      courseId: curso.id,
      title: "Rutas de evacuación y punto de reunión",
      type: "texto",
      order: 3,
      content:
        "Cada área de la planta debe tener señalización visible de rutas de evacuación y un punto de reunión asignado. Ante una alarma, camina sin correr, no uses elevadores y dirígete de inmediato a tu punto de reunión para el conteo de personal.",
    },
  ]);

  const [q1] = await db
    .insert(questions)
    .values({ courseId: curso.id, prompt: "¿Qué tipo de incendio involucra equipos eléctricos energizados?", type: "opcion_unica", order: 1 })
    .returning();
  await db.insert(options).values([
    { questionId: q1.id, text: "Clase A", isCorrect: false, order: 1 },
    { questionId: q1.id, text: "Clase B", isCorrect: false, order: 2 },
    { questionId: q1.id, text: "Clase C", isCorrect: true, order: 3 },
    { questionId: q1.id, text: "Clase D", isCorrect: false, order: 4 },
  ]);

  const [q2] = await db
    .insert(questions)
    .values({ courseId: curso.id, prompt: "El método PASS para usar un extintor comienza con...", type: "opcion_unica", order: 2 })
    .returning();
  await db.insert(options).values([
    { questionId: q2.id, text: "Apuntar a las llamas", isCorrect: false, order: 1 },
    { questionId: q2.id, text: "Presionar el seguro", isCorrect: true, order: 2 },
    { questionId: q2.id, text: "Correr hacia la salida", isCorrect: false, order: 3 },
    { questionId: q2.id, text: "Llamar a mantenimiento", isCorrect: false, order: 4 },
  ]);

  const [q3] = await db
    .insert(questions)
    .values({ courseId: curso.id, prompt: "Durante una evacuación, está permitido usar el elevador.", type: "verdadero_falso", order: 3 })
    .returning();
  await db.insert(options).values([
    { questionId: q3.id, text: "Verdadero", isCorrect: false, order: 1 },
    { questionId: q3.id, text: "Falso", isCorrect: true, order: 2 },
  ]);

  await db.insert(enrollments).values({
    courseId: curso.id,
    userId: empleado.id,
    status: "pendiente",
    progressPct: 0,
  });

  console.log("Listo. Usuarios de prueba:");
  console.log("  Admin     -> admin@mayco.com / Admin123!");
  console.log("  Empleado  -> empleado@mayco.com / Empleado123!");
}

main()
  .then(() => process.exit(0))
  .catch((err) => {
    console.error(err);
    process.exit(1);
  });
