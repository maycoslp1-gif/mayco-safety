import {
  sqliteTable,
  text,
  integer,
  real,
} from "drizzle-orm/sqlite-core";
import { relations, sql } from "drizzle-orm";

// ---------- Usuarios ----------
// role: "admin" | "empleado"
export const users = sqliteTable("users", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  role: text("role", { enum: ["admin", "empleado"] }).notNull().default("empleado"),
  area: text("area"), // ej. Producción, Mantenimiento, Logística
  puesto: text("puesto"),
  activo: integer("activo", { mode: "boolean" }).notNull().default(true),
  createdAt: text("created_at").notNull().default(sql`(current_timestamp)`),
});

// ---------- Cursos ----------
export const courses = sqliteTable("courses", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  title: text("title").notNull(),
  description: text("description").notNull().default(""),
  category: text("category").notNull().default("General"), // ej. Incendios, EPP, NOMs
  coverColor: text("cover_color").notNull().default("#0B3D91"),
  passingScore: integer("passing_score").notNull().default(80), // % mínimo para aprobar
  published: integer("published", { mode: "boolean" }).notNull().default(false),
  createdById: text("created_by_id").references(() => users.id),
  createdAt: text("created_at").notNull().default(sql`(current_timestamp)`),
  updatedAt: text("updated_at").notNull().default(sql`(current_timestamp)`),
});

// ---------- Módulos (contenido del curso) ----------
// type: "texto" | "video" | "pdf" | "imagen"
export const modules = sqliteTable("modules", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  courseId: text("course_id").notNull().references(() => courses.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  type: text("type", { enum: ["texto", "video", "pdf", "imagen"] }).notNull().default("texto"),
  content: text("content").notNull().default(""), // texto/markdown, o URL si es video/pdf/imagen
  order: integer("order").notNull().default(0),
});

// ---------- Asignación de cursos a empleados ----------
export const enrollments = sqliteTable("enrollments", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  courseId: text("course_id").notNull().references(() => courses.id, { onDelete: "cascade" }),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  status: text("status", { enum: ["pendiente", "en_progreso", "completado"] }).notNull().default("pendiente"),
  progressPct: integer("progress_pct").notNull().default(0),
  assignedAt: text("assigned_at").notNull().default(sql`(current_timestamp)`),
  completedAt: text("completed_at"),
});

// ---------- Preguntas del examen ----------
// type: "opcion_unica" | "verdadero_falso"
export const questions = sqliteTable("questions", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  courseId: text("course_id").notNull().references(() => courses.id, { onDelete: "cascade" }),
  prompt: text("prompt").notNull(),
  type: text("type", { enum: ["opcion_unica", "verdadero_falso"] }).notNull().default("opcion_unica"),
  order: integer("order").notNull().default(0),
});

export const options = sqliteTable("options", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  questionId: text("question_id").notNull().references(() => questions.id, { onDelete: "cascade" }),
  text: text("text").notNull(),
  isCorrect: integer("is_correct", { mode: "boolean" }).notNull().default(false),
  order: integer("order").notNull().default(0),
});

// ---------- Intentos de examen ----------
export const examAttempts = sqliteTable("exam_attempts", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  courseId: text("course_id").notNull().references(() => courses.id, { onDelete: "cascade" }),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  score: real("score").notNull(), // 0-100
  passed: integer("passed", { mode: "boolean" }).notNull(),
  answersJson: text("answers_json").notNull().default("{}"), // snapshot de respuestas dadas
  takenAt: text("taken_at").notNull().default(sql`(current_timestamp)`),
});

// ---------- Relaciones ----------
export const usersRelations = relations(users, ({ many }) => ({
  enrollments: many(enrollments),
  examAttempts: many(examAttempts),
}));

export const coursesRelations = relations(courses, ({ many }) => ({
  modules: many(modules),
  questions: many(questions),
  enrollments: many(enrollments),
  examAttempts: many(examAttempts),
}));

export const modulesRelations = relations(modules, ({ one }) => ({
  course: one(courses, { fields: [modules.courseId], references: [courses.id] }),
}));

export const questionsRelations = relations(questions, ({ one, many }) => ({
  course: one(courses, { fields: [questions.courseId], references: [courses.id] }),
  options: many(options),
}));

export const optionsRelations = relations(options, ({ one }) => ({
  question: one(questions, { fields: [options.questionId], references: [questions.id] }),
}));

export const enrollmentsRelations = relations(enrollments, ({ one }) => ({
  course: one(courses, { fields: [enrollments.courseId], references: [courses.id] }),
  user: one(users, { fields: [enrollments.userId], references: [users.id] }),
}));

export const examAttemptsRelations = relations(examAttempts, ({ one }) => ({
  course: one(courses, { fields: [examAttempts.courseId], references: [courses.id] }),
  user: one(users, { fields: [examAttempts.userId], references: [users.id] }),
}));
