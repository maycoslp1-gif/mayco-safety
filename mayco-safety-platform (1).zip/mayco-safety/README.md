# Mayco Automotive · Plataforma de Capacitación en Seguridad

Plataforma web para capacitar al personal de planta en temas de seguridad e
higiene. Incluye panel de administrador para subir cursos y dar seguimiento,
y una app para empleados (optimizada para celular) donde toman los cursos y
presentan un examen que se califica automáticamente.

## Qué incluye

- **Panel de administrador** (`/admin`): crear/editar cursos, agregar módulos
  de contenido (texto, video, PDF, imagen) **subiendo el archivo directamente
  o pegando una URL**, construir el examen (opción múltiple o
  verdadero/falso), asignar cursos a empleados, dar de alta empleados, y ver
  el registro completo de calificaciones.
- **App de empleado** (`/app`): ver cursos asignados, avanzar módulo por
  módulo desde el celular, presentar el examen y ver su calificación al
  instante, **descargar un certificado en PDF** al aprobar, y consultar su
  historial de exámenes (con certificados descargables en cualquier momento).
- **Calificación automática**: el sistema compara las respuestas contra la
  opción correcta guardada en cada pregunta y calcula el porcentaje; si supera
  el mínimo aprobatorio del curso (configurable, 80% por defecto), el curso
  se marca como completado y se habilita el certificado.

## Stack técnico

- **Next.js 16** (TypeScript, App Router) — frontend y backend en un solo proyecto
- **Drizzle ORM + SQLite (libSQL)** — base de datos. Migra fácilmente a un
  SQLite remoto (Turso) o a Postgres si lo prefieres más adelante.
- **NextAuth v5** — autenticación con roles (administrador / empleado)
- **Tailwind CSS** — interfaz responsiva, mobile-first

> Nota: se usó Drizzle en vez de Prisma porque Prisma requiere descargar
> binarios desde un servidor externo que no estaba disponible en el entorno
> donde se generó este proyecto. Drizzle funciona igual de bien y es 100%
> compatible con despliegues normales (Vercel, Railway, VPS, etc).

## Cómo correrlo en tu computadora

Requisitos: Node.js 20 o superior.

```bash
npm install
npx drizzle-kit migrate   # crea las tablas
npx tsx src/db/seed.ts    # crea un admin y un curso de ejemplo
npm run dev
```

Abre http://localhost:3000

**Usuarios de prueba (creados por el seed):**
- Administrador: `admin@mayco.com` / `Admin123!`
- Empleado: `empleado@mayco.com` / `Empleado123!`

⚠️ Cambia estas contraseñas antes de usarlo con datos reales, o bórralas y
crea tus propios usuarios desde el panel de administrador (Empleados → Nuevo
empleado).

## Cómo desplegarlo en producción (para que tus empleados lo usen desde su celular)

Como ya tienes cuenta en **Vercel** y en **Turso**, estos son los pasos
exactos:

### 1. Sube el código a GitHub
Crea un repositorio nuevo (puede ser privado) y sube esta carpeta completa.

### 2. Crea la base de datos en Turso
```bash
# Si no tienes la CLI de turso instalada:
curl -sSfL https://get.tur.so/install.sh | bash

turso auth login
turso db create mayco-seguridad
turso db show mayco-seguridad --url
turso db tokens create mayco-seguridad
```
Guarda la URL (empieza con `libsql://...`) y el token que te dio el último
comando.

### 3. Aplica las migraciones y el seed contra la base de Turso
```bash
DATABASE_URL="libsql://tu-url-de-turso" DATABASE_AUTH_TOKEN="tu-token" npx drizzle-kit migrate
DATABASE_URL="libsql://tu-url-de-turso" DATABASE_AUTH_TOKEN="tu-token" npx tsx src/db/seed.ts
```

### 4. Importa el proyecto en Vercel
En vercel.com → "Add New Project" → selecciona tu repositorio.

En **Environment Variables**, agrega:
| Variable | Valor |
|---|---|
| `DATABASE_URL` | la URL `libsql://...` de Turso |
| `DATABASE_AUTH_TOKEN` | el token de Turso |
| `AUTH_SECRET` | genera uno con `openssl rand -hex 32` |
| `AUTH_TRUST_HOST` | `true` |

### 5. Activa Vercel Blob (para que la subida de archivos funcione)
Dentro de tu proyecto en Vercel: pestaña **Storage** → **Create Database** →
**Blob**. Al conectarlo, Vercel agrega automáticamente la variable
`BLOB_READ_WRITE_TOKEN` — no necesitas copiar nada manualmente.

### 6. Despliega
Click en **Deploy**. En unos minutos tendrás una URL pública (ej.
`https://mayco-capacitacion.vercel.app`) lista para que tus empleados entren
desde el navegador de su celular, sin instalar nada.

> Para correrlo en tu computadora mientras tanto, sigue usando la sección de
> arriba ("Cómo correrlo en tu computadora") — usa SQLite local y guarda los
> archivos subidos en `public/uploads`, sin necesidad de Turso ni Vercel Blob.

## Estructura del proyecto

```
src/
  app/
    admin/          → panel de administrador
    app/             → app de empleado
    login/           → pantalla de inicio de sesión
    api/auth/        → endpoints de autenticación
  components/        → componentes de interfaz reutilizables
  db/
    schema.ts        → estructura de la base de datos
    seed.ts          → datos de ejemplo
  lib/
    auth.ts          → configuración de autenticación
    actions/         → lógica de negocio (crear cursos, calificar examen, etc.)
```

## Próximos pasos sugeridos

- Notificaciones por correo cuando se asigna un curso nuevo.
- Reportes exportables a Excel para auditorías de STPS.
- Pantalla para crear más usuarios administradores desde la interfaz.
- Recordatorios automáticos a empleados con cursos pendientes.

Si quieres que integre cualquiera de estos, dímelo y seguimos construyendo
sobre esta misma base.
